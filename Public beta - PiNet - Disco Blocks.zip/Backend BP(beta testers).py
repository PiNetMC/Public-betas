#0,0,0 = 46, 0, -28
import random
from mcpi import minecraft
from time import sleep
mc = minecraft.Minecraft.create()
while True:
    sec = random.randint(1,9)
    sleep(6)
    if sec == 9:
        print("pink")
        mc.setBlocks(-1, -15, -46, 1, -15, -48, 0)
        sleep(5)
        mc.setBlocks(-1, -15, -46, 1, -15, -48, 35, 6)
    elif sec == 8:
        print("purple")
        mc.setBlocks(3, -15, -46, 5, -15, -48, 0)
        sleep(5)
        mc.setBlocks(3, -15, -46, 5, -15, -48, 35, 10)
    elif sec == 7:
        print("white")
        mc.setBlocks(-5, -15, -52, -3, -15, -50, 0)
        sleep(5)
        mc.setBlocks(-5, -15, -52, -3, -15, -50, 35, 0)
    elif sec == 6:
        print("blue")
        mc.setBlocks(3, -15, -52, 5, -15, -50, 0)
        sleep(5)
        mc.setBlocks(3, -15, -52, 5, -15, -50, 35, 11)
    elif sec == 5:
        print("green")
        mc.setBlocks(-5, -15, -46, -3, -15, -48, 0)
        sleep(5)
        mc.setBlocks(-5, -15, -46, -3, -15, -48, 35, 13)
    elif sec == 4:
        print("orange")
        mc.setBlocks(-1, -15, -52, 1, -15, -50, 0)
        sleep(5)
        mc.setBlocks(-1, -15, -52, 1, -15, -50, 35, 1)
    elif sec == 3:
        print("red")
        mc.setBlocks(3, -15, -54, 5, -15, -56, 0)
        sleep(5)
        mc.setBlocks(3, -15, -54, 5, -15, -56, 35, 14)
    elif sec == 2:
        print("yellow")
        mc.setBlocks(-1, -15, -54, 1, -15, -56, 0)
        sleep(5)
        mc.setBlocks(-1, -15, -54, 1, -15, -56, 35, 4)
    elif sec == 1:
        print("brown")
        mc.setBlocks(-5, -15, -54, -3, -15, -56, 0)
        sleep(5)
        mc.setBlocks(-5, -15, -54, -3, -15, -56, 35, 12)